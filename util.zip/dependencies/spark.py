"""
spark.py
~~~~~~~~

Module containing helper function for use with Apache Spark
"""

import __main__

from pyspark.sql import SparkSession

def startSpark(appName='sparkapp'):
    spark = SparkSession.builder.appName(appName).getOrCreate()
    #spark.sparkContext.setLogLevel('ERROR')
    return spark